import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Fetch initial XML data (single artifact) from property
    def initialXml = message.getProperty("MessageContent")
    
    // Fetch error information string from message body
    def errorInfo = message.getBody(String)
    
    // Parse the initial XML data
    def xmlParser = new XmlParser()
    def artifact = xmlParser.parseText(initialXml)
    
    // Add ErrorInformation to the XML node
    artifact.appendNode("ErrorInformation", errorInfo)
    
    // Convert the updated XML back to string
    def updatedXml = XmlUtil.serialize(artifact)
    message.setBody(updatedXml)
    
    return message
}
