import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def jsonString = message.getBody(String)
    def json = new JsonSlurper().parseText(jsonString)
    
    def errorMessage = new StringBuilder()
    
    // Recursive function to process each message and its children
    def processMessage
    processMessage = { msg, params ->
        def subsystemName = msg.message.subsystemName ?: ""
        def subsystemPartName = msg.message.subsytemPartName ?: ""
        def messageId = msg.message.messageId ?: ""
        def messageText = msg.message.messageText ?: ""

        // Replace parameters in the message text
        params.eachWithIndex { param, index ->
            messageText = messageText.replace("{$index}", param)
        }

        // Format the message
        errorMessage << "[${subsystemName}][${subsystemPartName}][${messageId}] ${messageText}\n"

        // Process child instances recursively
        msg.childInstances.each { child ->
            processMessage(child, child.parameter)
        }
    }
    
    // Start processing from the root message
    processMessage(json, json.parameter ?: [])

    // Set the error message to the message body or a property
    message.setBody(errorMessage.toString().trim())
    
    return message
}
