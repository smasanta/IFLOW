import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
// Fetch XML data from the message body and convert it to a String
    def xmlData = message.getBody(String)

    // Parse the XML data
    def parser = new XmlParser()
    def root = parser.parseText(xmlData)
    
    // Build HTML content
    def html = new StringBuilder()
    html << '<html><head><style>'
    html << 'table { border-collapse: collapse; width: 100%; font-size: 12px; }'
    html << 'th, td { border: 1px solid black; padding: 4px; text-align: left; }'
    html << 'th { background-color: #f2f2f2; }'
    html << 'tr:nth-child(even) { background-color: #f9f9f9; }'
    html << 'td { word-wrap: break-word; max-width: 200px; }'  // Adjust max-width for better fitting
    html << '</style></head><body>'
    html << '<h2>Integration Runtime Artifacts Report</h2>'
    html << '<p>The following interfaces have been identified as going down:</p>'
    html << '<table>'
    html << '<tr><th>Status</th><th>Id</th><th>Name</th><th>Error Information</th></tr>'

    // Process the XML data
    root.'multimap:Message1'.IntegrationRuntimeArtifacts.each { artifacts ->
        def artifact = artifacts.IntegrationRuntimeArtifact
        def errorInfo = artifacts.ErrorInformation.text()
        html << '<tr>'
        html << "<td>${artifact.Status.text()}</td>"
        html << "<td>${artifact.Id.text()}</td>"
        html << "<td>${artifact.Name.text()}</td>"
        html << "<td>${errorInfo}</td>"
        html << '</tr>'
    }

    html << '</table>'
    html << '</body></html>'

    // Convert HTML content to String and set it as the message body
    def styledHtml = html.toString()
    message.setBody(styledHtml)
    
    return message
}