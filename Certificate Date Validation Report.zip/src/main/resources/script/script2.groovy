import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    
    def xml = body
    
    // Parse the XML
    def parsedXml = new groovy.util.XmlParser().parseText(xml)
    
    // Start the HTML table
    def html = new StringBuilder()
    
    html.append("<p>Hi Team,<br/><br/>attatched is this weeks report of expiring certifactes within SAP Integratin Suite (CPI).</p>")
    html.append("<table border='1'>\n")
    html.append("<tr><th>Owner</th><th>CreatedBy</th><th>Alias</th><th>ValidNotAfter</th><th>RemainingDays</th><th>Validity</th></tr>\n")
    
    // Iterate over each KeystoreEntry
    parsedXml.KeystoreEntry.each { entry ->
        if (entry.RemainingDays.text().toInteger() <= 28) {
            html.append("<tr>")
            html.append("<td>${entry.Owner.text()}</td>")
            html.append("<td>${entry.CreatedBy.text()}</td>")
            html.append("<td>${entry.Alias.text()}</td>")
            html.append("<td>${entry.ValidNotAfter.text()}</td>")
            html.append("<td>${entry.RemainingDays.text()}</td>")
            
            // Determine the color for the 'Valid' column based on RemainingDays
            def remainingDays = entry.RemainingDays.text() as Integer
            def validStatusColor = remainingDays <= 0 ? 'red' : 'yellow'
            def validStatusText = remainingDays <= 0 ? 'Invalid' : 'Valid'
            
            html.append("<td style='background-color: ${validStatusColor};'>${validStatusText}</td>")
            html.append("</tr>\n")
        }
    }
    
    // Close the table
    html.append("</table>")
    
    message.setBody(html)
    
    return message;
}