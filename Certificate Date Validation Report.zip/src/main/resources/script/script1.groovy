import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date
import java.text.SimpleDateFormat
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import java.time.LocalDate

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    
    def xml = new XmlParser().parseText(body)
    
    Date date = new Date()
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    String formattedDate = dateFormat.format(date)
    
    xml.'KeystoreEntry'.each { artifact ->
        def expiration = artifact.ValidNotAfter[0].text()
        def formattedExpiration = dateFormat.parse(expiration)
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

        // Parse the string dates into LocalDate objects
        LocalDate startDate = LocalDate.parse(formattedDate.toString(), formatter)
        LocalDate endDate = LocalDate.parse(expiration.split("T")[0].toString(), formatter)

        // Calculate the difference in days
        long daysBetween = ChronoUnit.DAYS.between(startDate, endDate)

        artifact.appendNode('RemainingDays', daysBetween)
    }

    def output = XmlUtil.serialize(xml)

    message.setBody(output)
    
    return message;
}