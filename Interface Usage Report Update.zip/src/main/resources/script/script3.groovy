import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Body 
    def pMap = message.getProperties();
    if(pMap.get("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){
       def body = message.getBody(java.lang.String);
       def messageLog = messageLogFactory.getMessageLog(message);
       messageLog.addAttachmentAsString("mapped-data",body,'application/xml');
    }

    return message;
}
