import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;

def Message processData(Message message) {
    def body = message.getBody(String);
    
    def date = new Date();
    message.setHeader('Date', date);
    
    def xml = body;
    
    def parsedXml = new groovy.util.XmlParser().parseText(xml);
    
    // Separate artifacts based on Usage value
    def artifactsWithUsage = []
    def artifactsWithoutUsage = []
    
    parsedXml.'multimap:Message1'.IntegrationRuntimeArtifacts.IntegrationRuntimeArtifact.each { artifact ->
        if (artifact.Usage.text().toInteger() > 0) {
            artifactsWithUsage.add(artifact)
        } else {
            artifactsWithoutUsage.add(artifact)
        }
    }
    
    // Generate tables
    StringBuilder htmlTable = new StringBuilder()
    
    artifactsWithUsage.each { artifact ->
        htmlTable.append("<tr><td>${artifact.Name.text()}</td><td>${artifact.Id.text()}</td><td>${artifact.Usage.text()}</td><td>${artifact.Fails.text()}</td><td></td><td>${artifact.PackageName.text()}</td><td>${artifact.PackageID.text()}</td></tr>")
    }
    
    def htmlTablesWithUsage = htmlTable.toString();
    

    StringBuilder htmlTable2 = new StringBuilder()
    
    artifactsWithoutUsage.each { artifact ->
        htmlTable2.append("<tr><td>${artifact.Name.text()}</td><td>${artifact.Id.text()}</td><td>${artifact.PackageName.text()}</td><td>${artifact.PackageID.text()}</td></tr>")
    }
    
    def htmlTablesWithoutUsage = htmlTable2.toString();
    
    def htmlFile = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAP Integration Report</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f9;
            color: #333;
            margin: 20px;
        }

        h1 {
            text-align: center;
            color: #004080;
        }

        /* Table Styles */
        table {
            width: 100%;
            max-width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #004080;
            color: white;
            cursor: pointer;
            position: relative;
        }

        th .sort-icon {
            margin-left: 5px;
            font-size: 12px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e0e0e0;
        }

        /* Page Navigation Styles */
        .nav-buttons {
            text-align: center;
            margin-top: 20px;
        }

        .nav-buttons button {
            background-color: #004080;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 5px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-buttons button:hover {
            background-color: #0066cc;
        }

        /* Page Section Styles */
        .page {
            display: none;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .active {
            display: block;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            table {
                font-size: 14px;
            }

            .nav-buttons button {
                width: 100%;
                margin: 5px 0;
            }
        }
    </style>
</head>

<body>

    <h1>SAP CPI Test Integration Report</h1>
    <div class="nav-buttons">
        <button onclick="showPage('page1')">Usage</button>
        <button onclick="showPage('page2')">Unused</button>
        <button onclick="showPage('page3')">N/A</button>
    </div>
    <div id="page1" class="page active">
        <h1>Interfaces with Usage</h1>
        <table border='1' style='border-collapse: collapse;' id="myTable">
            <tr>
                <th onclick="sortTable(0, 'text')">Name<span class="sort-icon"></span></th>
                <th onclick="sortTable(1, 'text')">ID<span class="sort-icon"></span></th>
                <th onclick="sortTable(2, 'number')">Usage<span class="sort-icon"></span></th>
                <th onclick="sortTable(3, 'number')">Fails<span class="sort-icon"></span></th>
                <th onclick="sortTable(4, 'number')">Success-Rate <span class="sort-icon"></span></th>
                <th onclick="sortTable(5, 'text')">Package Name<span class="sort-icon"></span></th>
                <th onclick="sortTable(6, 'text')">Package Id<span class="sort-icon"></span></th>
            </tr>
    
    ''' + htmlTablesWithUsage + '''
            </table>
    </div>
    <br><br>
    <div id="page2" class="page">
     <h1>Unused Interfaces</h1>
        <table border='1' style='border-collapse: collapse;'>
            <tr>
                <th>Name</th>
                <th>Id</th>
                <th>Package Name</th>
                <th>Package Id</th>
            </tr>
    ''' + htmlTablesWithoutUsage + ''' </table>
    </div>
    <script>
        function sortTable(columnIndex, type) {
            var table = document.getElementById("myTable");
            var rows = Array.from(table.rows).slice(1); // Exclude header row
            var isAscending = table.dataset.sortOrder !== "asc"; // Toggle sort order

            // Sort rows based on the content of the clicked column
            rows.sort(function (a, b) {
                var cellA = a.cells[columnIndex].innerText.toLowerCase();
                var cellB = b.cells[columnIndex].innerText.toLowerCase();

                if (type === 'number') {
                    // Convert to numbers for numerical sorting
                    cellA = parseFloat(cellA);
                    cellB = parseFloat(cellB);
                }

                if (cellA < cellB) return isAscending ? -1 : 1;
                if (cellA > cellB) return isAscending ? 1 : -1;
                return 0;
            });

            // Update the table with sorted rows
            rows.forEach(row => table.tBodies[0].appendChild(row));

            // Toggle the sort order
            table.dataset.sortOrder = isAscending ? "asc" : "desc";

            // Update sort icon
            updateSortIcons(columnIndex, isAscending);
        }

        function updateSortIcons(columnIndex, isAscending) {
            // Clear all sort icons
            var headers = document.querySelectorAll('#myTable th');
            headers.forEach(function (header, index) {
                var icon = header.querySelector('.sort-icon');
                if (icon) {
                    icon.innerHTML = '';
                    if (index === columnIndex) {
                        icon.innerHTML = isAscending ? '▲' : '▼'; // Up or Down arrow
                    }
                }
            });
        }

        function showPage(pageId) {
            // Hide all pages
            var pages = document.querySelectorAll('.page');
            pages.forEach(function (page) {
                page.classList.remove('active');
            });

            // Show the selected page
            document.getElementById(pageId).classList.add('active');
        }

        // Calculate success rate for each row
        function calculateSuccessRates() {
            var table = document.getElementById("myTable");
            var rows = table.querySelectorAll("tbody tr");

            rows.forEach(function (row) {
                if (row.cells[4].innerText != 'Success-Rate') {


                    var usage = parseFloat(row.cells[2].innerText);
                    var fails = parseFloat(row.cells[3].innerText);
                    var successRateCell = row.cells[4];

                    if (usage > 0) {
                        var successRate = ((usage - fails) / usage) * 100;
                        successRateCell.innerText = successRate.toFixed(2) + '%';
                    } else {
                        successRateCell.innerText = 'N/A';
                    }
                }
            });
        }


        window.onload = function () {
            calculateSuccessRates();
        };
    </script>
</body>

</html>'''
    
    
    message.setBody(htmlFile);
    
    return message;
}
