import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.StreamingMarkupBuilder;
import java.util.Date
import java.text.SimpleDateFormat

def Message processData(Message message) {
    // //Body
    // def body = message.getBody(String);
    
    // def xml = new XmlParser().parseText(body)
    
    // xml.'IntegrationRuntimeArtifact'.each { artifact ->
    //     artifact.appendNode('Usage', '0')
    //     artifact.appendNode('Fails', '0')
    //     artifact.appendNode('PackageName', '0')
    //     artifact.appendNode('PackageId', '0')
    // }

    // def output = XmlUtil.serialize(xml)

    // message.setBody(output)
    
    Date date = new Date() - 90
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    String formattedDate = dateFormat.format(date)
    
    message.setProperty('filterDate', formattedDate)
    
    return message;
}