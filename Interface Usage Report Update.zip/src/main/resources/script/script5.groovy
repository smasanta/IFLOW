import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil;

def Message processData(Message message) {
    //Body
    def body = message.getBody();
    def properties = message.getProperties();
    
    def artifactsXml = new XmlSlurper(false, false).parseText(properties.get("IntegrationContent"))
    def logsXml = new XmlSlurper(false, false).parseText(body)
    
    def idUsageMap = [:].withDefault { 0 }
    logsXml.'**'.findAll { it.name() == 'MessageProcessingLog' }.each { log ->
        def id = log.IntegrationArtifact.Id.text()
        idUsageMap[id] = idUsageMap[id] + 1
    }
    
    // Parse the artifacts XML and update the Usage based on Id occurrences
    def updated = artifactsXml.depthFirst().findAll { it.name() == 'IntegrationRuntimeArtifact' }.any { artifact ->
        def id = artifact.Id.text()
        if (idUsageMap.containsKey(id)) {
            def currentUsage = artifact.Usage.text().toInteger()
            artifact.Usage.replaceBody(currentUsage + idUsageMap[id])
            true // Indicates modification
        } else {
            false // No modification
        }
    }
    
    // Convert the updated artifacts XML back to a String if any modifications were made
    def xmlOutput = ''
    if (updated) {
        xmlOutput = XmlUtil.serialize(new StreamingMarkupBuilder().bind {
            mkp.yield artifactsXml
        })
    }
    
    message.setProperty('IntegrationContent', xmlOutput)
    
    return message;
}