import groovy.xml.XmlUtil
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.StreamingMarkupBuilder;

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    
    def xml = new XmlParser().parseText(body)
    
    xml.'**'.Usage*.replaceNode{
        Usage(message.getProperty('Count'))
    }
    
    xml.'**'.PackageName*.replaceNode{
        PackageName(message.getProperty('PackageName'))
    }
    
    xml.'**'.PackageId*.replaceNode{
        PackageId(message.getProperty('PackageId'))
    }
    
        xml.'**'.Fails*.replaceNode{
        Fails(message.getProperty('Fails'))
    }
    
    def output = XmlUtil.serialize(xml)

    message.setBody(output)
    
    return message;
}