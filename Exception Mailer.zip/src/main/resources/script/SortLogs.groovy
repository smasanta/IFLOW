import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import groovy.util.XmlSlurper

def Message processData(Message message) {
    // Assume 'inputXml' is a String containing your XML data
    def inputXml = message.getBody(String) // Replace with your actual XML content
    
    // Parse the XML
    def parsedXml = new XmlSlurper().parseText(inputXml)
    
    // Group entries by 'PackageName' and 'IntegrationFlowName'
    def groupedByPackage = parsedXml.Entry.groupBy { it.PackageName.text() }
    def groupedAndSorted = groupedByPackage.collectEntries { packageName, entries ->
        def groupedByFlow = entries.groupBy { it.IntegrationFlowName.text() }
        def sortedByFlow = groupedByFlow.collectEntries { flowName, flowEntries ->
            [(flowName): flowEntries.sort { a, b -> a.Id.text() <=> b.Id.text() }]
        }
        [(packageName): sortedByFlow]
    }
    
    // Build the sorted and grouped XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    
    xml.Feed {
        groupedAndSorted.each { packageName, flows ->
            Package (name: packageName) {
                flows.each { flowName, entries ->
                    Flow(name: flowName) {
                        entries.each { entry ->
                            Entry {
                                MessageGuid(entry.MessageGuid.text())
                                AlternateWebLink(entry.AlternateWebLink.text())
                                IntegrationFlowName(entry.IntegrationFlowName.text())
                                Status(entry.Status.text())
                                LogStart(entry.LogStart.text())
                                LogEnd(entry.LogEnd.text())
                                Error(entry.Error.text())
                                PackageName(packageName)
                                PackageId(entry.PackageId.text())
                                Type(entry.Type.text())
                                Name(entry.Name.text())
                                Id(entry.Id.text())
                            }
                        }
                    }
                }
            }
        }
    }
    
    def sortedXml = writer.toString()
    
    message.setBody(sortedXml)
    
    return message
}
