import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.TimeZone

// This method is called by the integration flow when the script is executed
def Message processData(Message message) {
    // Set the timezone if needed, otherwise UTC is used
    TimeZone.setDefault(TimeZone.getTimeZone('UTC'))

    // Get the current date and time
    Calendar cal = Calendar.getInstance()
    // Subtract 15 minutes and 15 seconds
    cal.add(Calendar.MINUTE, -15)
    cal.add(Calendar.SECOND, -15)

    // Define the date format for the filter
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    // Format the date
    String formattedDate = sdf.format(cal.getTime())

    // Store the formatted date in the message property to use in the OData call
    message.setProperty("filterDate", formattedDate)

    // Return the modified message
    return message
}
