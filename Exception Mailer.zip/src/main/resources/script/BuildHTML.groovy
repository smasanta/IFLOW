import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {
// Your XML string
    def xmlString = message.getBody(String)
    
    // Parse the XML
    def packageXml = new XmlSlurper().parseText(xmlString)
    def packageName = packageXml.@name
    def packageEmail = packageXml.@email
    def flows = packageXml.Flow
    
    message.setProperty("Subject", "Errors in ${packageName}")
    message.setProperty("ContactEmail", "${packageEmail}")
    
    def htmlContent = new StringBuilder()
    htmlContent.append("<html><body>")
    htmlContent.append("<style>")
    htmlContent.append("body { font-family: Arial, sans-serif; }")
    htmlContent.append("h1, h2 { color: #333; }")
    htmlContent.append(".error-box { border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; }")
    htmlContent.append(".error-details { color: #d00; }")
    htmlContent.append("</style>")
    htmlContent.append("<h1>Error Report for Package: ${packageName}</h1>")
    
    flows.each { flow ->
        def flowName = flow.@name
        def entries = flow.Entry.groupBy { it.Error.text().replaceAll("The MPL ID for the failed message is :.*", "") }
        htmlContent.append("<h2>${flowName} Errors</h2>")
    
        entries.each { error, errorEntries ->
            htmlContent.append("<div class='error-box'>")
            htmlContent.append("<p>${errorEntries.size()} occurrence(s) of error:</p>")
            htmlContent.append("<ul>")
            errorEntries.each { entry ->
                 def alternateWebLink = entry.AlternateWebLink.text() // Assuming you have this field in your XML
                htmlContent.append("<li><a href='${alternateWebLink}' target='_blank'>Message ID: ${entry.MessageGuid.text()}</a></li>")
            }
            htmlContent.append("</ul>")
            htmlContent.append("<p class='error-details'>Error Details: ${error}</p>")
            htmlContent.append("</div>")
        }
    }
    
    htmlContent.append("</body></html>")
        // Set the output back on the message body
    message.setBody(htmlContent.toString())

    return message
}
