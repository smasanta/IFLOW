import com.sap.gateway.ip.core.customdev.util.Message
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import groovy.xml.MarkupBuilder
import java.io.StringWriter

def Message processData(Message message) {
    int daysInThePast = 3
    
    LocalDate today = LocalDate.now()
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    StringWriter writer = new StringWriter()
    MarkupBuilder xml = new MarkupBuilder(writer)
    
    xml.dates {
        for (int i = 0; i < daysInThePast; i++) {
            LocalDate pastDate = today.minusDays(i)
            date(pastDate.format(formatter))
        }
    }
    
    // Generating XML string for past dates
    String pastDatesXML = writer.toString()
    
    message.setBody(pastDatesXML)
    
    return message
}