import groovy.xml.MarkupBuilder
import groovy.util.XmlSlurper
import com.sap.gateway.ip.core.customdev.util.Message
import java.io.StringWriter

def Message processData(Message message) {
    // Get the XML body from the message
    def body = message.getBody(String)
    def xml = new XmlSlurper(false, false).parseText(body)

    StringWriter writer = new StringWriter()
    def builder = new MarkupBuilder(writer)
    
    // Build the new XML
    builder.IntegrationRuntimeArtifacts {
        xml.IntegrationRuntimeArtifact.each { artifact ->
            builder.IntegrationRuntimeArtifact {
                artifact.children().each { child ->
                    // Copy existing elements
                    builder."${child.name()}" "${child.text()}"
                }
                // Add new elements
                builder.Usage('0')
                builder.PackageID('defaultPackageID')
                builder.PackageName('defaultPackageName')
            }
        }
    }

    // Set the modified XML as the new body
    message.setBody(writer.toString())
    
    return message
}
