import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.Date;

def Message processData(Message message) {
    def body = message.getBody(String);
    
    def date = new Date();
    message.setHeader('Date', date);
    
    def xml = body;
    
    def parsedXml = new groovy.util.XmlParser().parseText(xml);
    
    // Separate artifacts based on Usage value
    def artifactsWithUsage = []
    def artifactsWithoutUsage = []
    
    parsedXml.'multimap:Message1'.IntegrationRuntimeArtifacts.IntegrationRuntimeArtifact.each { artifact ->
        if (artifact.Usage.text().toInteger() > 0) {
            artifactsWithUsage.add(artifact)
        } else {
            artifactsWithoutUsage.add(artifact)
        }
    }
    
    // Generate tables
    def htmlTablesWithUsage = generateHtmlTable(artifactsWithUsage, "Interfaces with Usage")
    def htmlTablesWithoutUsage = generateHtmlTable2(artifactsWithoutUsage, "Interfaces without Usage")
    
    // Combine both tables
    def combinedHtmlTables = new StringBuilder()
    combinedHtmlTables.append("Hi Team,<br/><br/>attached is this month’s report on the SAP Integration Suite (CPI) Interface usage.")
    combinedHtmlTables.append(htmlTablesWithUsage).append("<br><br>").append(htmlTablesWithoutUsage)
    
    message.setBody(combinedHtmlTables.toString());
    
    return message;
}

String generateHtmlTable(def artifacts, String title) {
    StringBuilder htmlTable = new StringBuilder()
    htmlTable.append("<h1>").append(title).append("</h1>\n")
    htmlTable.append("<table border='1' style='border-collapse: collapse;'>\n")
    htmlTable.append("<tr><th>Type</th><th>Id</th><th>Usage</th><th>Fails</th><th>PackageName</th><th>PackageId</th></tr>\n")
    
    artifacts.each { artifact ->
        htmlTable.append("<tr>")
        htmlTable.append("<td>${artifact.Type.text()}</td>")
        htmlTable.append("<td>${artifact.Id.text()}</td>")
        htmlTable.append("<td>${artifact.Usage.text()}</td>")
        htmlTable.append("<td>${artifact.Fails.text()}</td>")
        htmlTable.append("<td>${artifact.PackageName.text()}</td>")
        htmlTable.append("<td>${artifact.PackageId.text()}</td>")
        htmlTable.append("</tr>\n")
    }
    
    htmlTable.append("</table>")
    return htmlTable.toString();
}

String generateHtmlTable2(def artifacts, String title) {
    StringBuilder htmlTable = new StringBuilder()
    htmlTable.append("<h1>").append(title).append("</h1>\n")
    htmlTable.append("<table border='1' style='border-collapse: collapse;'>\n")
    htmlTable.append("<tr><th>Type</th><th>Id</th></tr>\n")
    
    artifacts.each { artifact ->
        htmlTable.append("<tr>")
        htmlTable.append("<td>${artifact.Type.text()}</td>")
        htmlTable.append("<td>${artifact.Id.text()}</td>")
        htmlTable.append("</tr>\n")
    }
    
    htmlTable.append("</table>")
    return htmlTable.toString();
}
