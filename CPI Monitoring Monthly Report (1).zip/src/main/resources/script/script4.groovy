import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.util.AttachmentWrapper;
import java.util.HashMap;
import javax.mail.util.ByteArrayDataSource;

def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;

// 2: Construct a ByteArrayDataSource object with the byte array and the content's MIME type
def dataSource = new ByteArrayDataSource(body, 'text/plain');

// 3: Construct a DefaultAttachment object
def attachment = new AttachmentWrapper(dataSource);

// 4: Add the attachment to the message
message.addAttachmentObject('MessageProcessing_Report.xls', attachment);

return message;
}

 