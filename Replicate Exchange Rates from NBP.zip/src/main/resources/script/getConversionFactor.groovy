import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	 
	 def body = message.getBody(java.io.Reader);
	 def root = new XmlSlurper().parse(body);
	 HashMap<String, String> map = new HashMap<String, String>();
	
	    root.Records.each{ record->
	        map.put(record.FromCurrency.toString(), record.FromRatio.toString());
	   }
	   message.setProperty("P_ConversionRate",map);
	   message.setBody(message.getProperty("CurrencyData"));
	 return message;
}
