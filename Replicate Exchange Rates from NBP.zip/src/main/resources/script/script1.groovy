import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    def allowedCodes = ['CHF', 'DKK', 'EUR', 'GBP', 'PLN', 'USD']
    
    def slurper = new XmlSlurper(false, false)
    def parsedXml = slurper.parseText(body)

    parsedXml.ExchangeRatesTable.Rates.Rate.findAll { !(it.Code.text() in allowedCodes) }.each { node ->
        node.replaceNode {}
    }
    
    def prettyXml = XmlUtil.serialize(parsedXml)
    
    message.setBody(prettyXml)
    
    return message;
}