import com.sap.it.api.mapping.*;
import java.util.*;

def String getValuefromProperty(String value ,MappingContext context)
{
     String output = context.getProperty(value);
	return output 
}

def void setCurrency(String[] conversionRate,String[] currency, Output output, MappingContext context)
{   
    String finalOutput = "";
    String flag = "false"
    for(int i=0; i<conversionRate.size(); i++){
        if(conversionRate[i].equals("N.A.")){
            flag = "true";
           finalOutput = finalOutput + "Currency:" + currency[i] + "  ConversionRate:" + conversionRate[i] + "\n";
            output.addSuppress();
        }
        else{
            output.addValue("");
        }
    }
    context.setProperty("P_Flag",flag);
    if(flag=="true"){
        context.setProperty("P_FailedList",finalOutput);
    }
}
