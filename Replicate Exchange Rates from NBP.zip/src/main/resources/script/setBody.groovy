import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.crypto.spec.DESKeySpec;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    List list = message.getProperty("P_List");
    String output = "";
    if(list!=null){
        for(String str: list){
            output = output+str+"\n";
        }
    }
    
    message.setProperty("CurrencyData",output);
   if(message.getProperty("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){
       def messageLog = messageLogFactory.getMessageLog(message);
       messageLog.addAttachmentAsString("ConnversionData",output,'text/xml');
       
   }
    message.setBody(output);
    return message;
}