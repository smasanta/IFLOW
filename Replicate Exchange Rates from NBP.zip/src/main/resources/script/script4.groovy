import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
    def pMap = message.getProperties();
    if(pMap.get("P_ENABLE_LOGGING").equalsIgnoreCase("TRUE")){
       def body = message.getBody(java.lang.String);
       def messageLog = messageLogFactory.getMessageLog(message);
       messageLog.addAttachmentAsString("pre-IDocs",body,'text/xml');
    }


    return message;
}