import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/




def String getDateTime(String inputValue, String identifier){
    String outputValue = "";
    if(inputValue.length() > 13){
        if(identifier.equalsIgnoreCase("D")){
            outputValue = inputValue.substring(0,8);
        }else if(identifier.equalsIgnoreCase("T")){
            outputValue = inputValue.substring(8);
        }
    }else{
        outputValue = "";
    }
	return outputValue 
}

def String getPropertyHeader(String propertyOrHeader,String propertHeaderName,MappingContext context) {
    String outputValue = "";
    
    if(propertyOrHeader.equalsIgnoreCase("P")){
        outputValue = context.getProperty(propertHeaderName);
    }else if(propertyOrHeader.equalsIgnoreCase("H")){
        outputValue = context.getHeader(propertHeaderName);
    }

    return outputValue;
}



def String itemDescription(String description,String fieldIdentifier, MappingContext context){
    String outputDescription = "";
    if(fieldIdentifier.equals("1")){
        def fieldLength = description.length();
        if(fieldLength > 0 && fieldLength <= 35){
            outputDescription = description.substring(0,fieldLength);
        }else if(fieldLength > 35){
            outputDescription = description.substring(0,35);
        }else{
            outputDescription = "";
        }
    }else{
        def fieldLength = description.length();
        if(fieldLength > 35 && fieldLength <= 70){
            outputDescription = description.substring(35,fieldLength);
        }else if(fieldLength > 70){
            outputDescription = description.substring(35,70);
        }else{
            outputDescription = "";
        } 
    }
	return outputDescription 
}

def void returnSingleValueFromQueue(String[] qualifier, String[] qualifierArray,String[] inputValuesArray, Output output, MappingContext context) {
        String outputValue = "";
        
        for(int i = 0; i < qualifierArray.length; i++){
            
            if(qualifierArray[i].equals(qualifier[0])){
                outputValue = inputValuesArray[i];
                break;
            }
            
        }

        output.addValue(outputValue);
}

def void returnSingleValueFromContext(String[] inputValuesArray, Output output, MappingContext context) {
        String outputValue = "";
        
        for(int i = 0; i < inputValuesArray.length; i++){
            
            if(!inputValuesArray[i].equals("")){
                outputValue = inputValuesArray[i];
                break;
            }
            
        }

        output.addValue(outputValue);
}


def void getLIFNR(String[] flag,String[] V_3039, String[] V_3225 , Output output, MappingContext context) {
    String outputValue = "";
    for(int i =0; i < flag.length; i++){    
        if(flag[i].equals("true")){
            outputValue = V_3039[i];
            if((!(V_3225[0] == null)) && (!(V_3225[0].equals("")))){
                outputValue = outputValue + V_3225[0];
                
            }
            
        }
        output.addValue(outputValue);
        outputValue = "";
    }
    
    
}




