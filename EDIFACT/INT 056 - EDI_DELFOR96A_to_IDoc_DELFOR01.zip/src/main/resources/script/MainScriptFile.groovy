import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;



def Message Log_Input_Payload(Message message) {


	def mapProp = message.getProperties();
	def property_ENABLE_PAYLOAD_LOGGING = mapProp.get("P_Log_Required");
	property_ENABLE_PAYLOAD_LOGGING = property_ENABLE_PAYLOAD_LOGGING.toUpperCase();

	if (property_ENABLE_PAYLOAD_LOGGING.toUpperCase().equals("TRUE")) {
		def header = message.getHeaders() as String;
		def body = message.getBody(java.lang.String) as String;
		def prop = message.getProperties() as String;

		String timeStamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
		String bodyLogTitle = "Input Payload";
        // String propLogTitle = "Properties Before Create_JSON_to_Create_Task";
// 		String propLogTitle = timeStamp + " DESCRIPTIONS properties ";

		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString(bodyLogTitle, body, "text/xml");
// 			messageLog.addAttachmentAsString(propLogTitle, prop, "text/xml");
		}
	}
	return message;
}


def Message Log_Acknowledgement_Payload(Message message) {


	def mapProp = message.getProperties();
/*	def property_ENABLE_PAYLOAD_LOGGING = mapProp.get("P_Log_Required");
	property_ENABLE_PAYLOAD_LOGGING = property_ENABLE_PAYLOAD_LOGGING.toUpperCase();*/
	property_ENABLE_PAYLOAD_LOGGING = "TRUE";
    def fileaname = mapProp.get("P_FileName");
    
	if (property_ENABLE_PAYLOAD_LOGGING.toUpperCase().equals("TRUE")) {
		def header = message.getHeaders() as String;
		def body = message.getBody(java.lang.String) as String;
		def prop = message.getProperties() as String;

		String timeStamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
		String bodyLogTitle = "Acknowledgement Payload";
		String fileNameLogTitle = "File Name";
        // String propLogTitle = "Properties Before Create_JSON_to_Create_Task";
// 		String propLogTitle = timeStamp + " DESCRIPTIONS properties ";

		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString(bodyLogTitle, body, "text/xml");
			messageLog.addAttachmentAsString(fileNameLogTitle, fileaname, "text/xml");
// 			messageLog.addAttachmentAsString(propLogTitle, prop, "text/xml");
		}
	}
	return message;
}


def Message GET_LOREALGLN(Message message) {
    def body = message.getBody(java.lang.String);
    def map = message.getProperties();
    def fileaname = map.get("P_FileName");
    String[] fileanameArray = fileaname.split("_");
    def P_LOREALGLN = fileanameArray[0];
    message.setProperty("P_LOREALGLN", P_LOREALGLN);
    return message;
}
