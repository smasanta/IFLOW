/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.mapping.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

def Message processData(Message message) {
	def mapProp = message.getProperties();
	def property_ENABLE_PAYLOAD_LOGGING = mapProp.get("P_Log_Required");
	property_ENABLE_PAYLOAD_LOGGING = property_ENABLE_PAYLOAD_LOGGING.toUpperCase();

	if (property_ENABLE_PAYLOAD_LOGGING.toUpperCase().equals("TRUE")) {
		def header = message.getHeaders() as String;
		def body = message.getBody(java.lang.String) as String;
		def prop = message.getProperties() as String;

		String timeStamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
		String bodyLogTitle = "IDoc";
        // String propLogTitle = "Properties Before Create_JSON_to_Create_Task";
// 		String propLogTitle = timeStamp + " DESCRIPTIONS properties ";

		def messageLog = messageLogFactory.getMessageLog(message);
		if (messageLog != null) {
			messageLog.addAttachmentAsString(bodyLogTitle, body, "text/xml");
// 			messageLog.addAttachmentAsString(propLogTitle, prop, "text/xml");
		}
	}
	return message;
}