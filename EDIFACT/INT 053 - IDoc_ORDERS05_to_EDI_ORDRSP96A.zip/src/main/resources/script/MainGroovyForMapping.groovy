import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String itemDescription(String description,String fieldIdentifier, MappingContext context){
    String outputDescription = "";
    if(fieldIdentifier.equals("1")){
        def fieldLength = description.length();
        if(fieldLength > 0 && fieldLength <= 35){
            outputDescription = description.substring(0,fieldLength);
        }else if(fieldLength > 35){
            outputDescription = description.substring(0,35);
        }else{
            outputDescription = "";
        }
    }else{
        def fieldLength = description.length();
        if(fieldLength > 35 && fieldLength <= 70){
            outputDescription = description.substring(35,fieldLength);
        }else if(fieldLength > 70){
            outputDescription = description.substring(35,70);
        }else{
            outputDescription = "";
        } 
    }
	return outputDescription 
}

def void e1edk03Datum002(String[] iddat,String[] datum, Output output, MappingContext context) {
        String dateValue = "";

        for(int i = 0; i < iddat.length; i++){
            if(iddat[i].equals("002")){
                dateValue = datum[i];
                break;
            }
        }
        output.addValue(dateValue);
}

def void childExist(String[] inputQueue, Output output, MappingContext context) {
        String outputValue = "false";

        for(int i = 0; i < inputQueue.length; i++){
            if(inputQueue[i].equals("true")){
                outputValue = "true";
                break;
            }
        }
        output.addValue(outputValue);
}

def void childExistValue(String[] inputQueue, String[] inputValue, Output output, MappingContext context) {
        String outputValue = "";

        for(int i = 0; i < inputQueue.length; i++){
            if(inputQueue[i].equals("true")){
                outputValue = inputValue[i];
                break;
            }
        }
        output.addValue(outputValue);
}



def void TDLINE(String[] tdline, String[] startNumber, Output output, MappingContext context) {
    if (startNumber[0].isInteger()) {
        int startNumberInt = startNumber[0] as Integer;
        
        for(int i = startNumberInt; i < tdline.length; ){
            output.addValue(tdline[i]);
            i = i+5;
        }
        
    }
}


def void S_FLX_TDLINE(String[] tdid, String[] tdline,  Output output,  MappingContext context) {
        String s_ftx = "";
        boolean Z016_found = false;

            if(tdid[0].equals("true")){
                Z016_found = true;
                int noOfTdline = tdline.length;
                int noOfLoop = (int)Math.ceil((noOfTdline/5.0));
                for(int i = 0; i < noOfLoop; i++){
                    output.addValue("true");
                }
            }

        if(!Z016_found){
            output.addValue("false");
        }
}

def String get_D_3039(String lifnr, MappingContext context){
    String outputValue = "";
    if(lifnr.length() >= 3){
        outputValue = lifnr.substring(0,3);
    }
    return outputValue;
}






