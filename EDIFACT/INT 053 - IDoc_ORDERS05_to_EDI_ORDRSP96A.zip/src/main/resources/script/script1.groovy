/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat
import java.io.*;

import java.text.DateFormat;
import java.util.Calendar;

def Message updateFileName(Message message) {

       def map = message.getHeaders();
       
       def IdocNumber = map.get("SAP_IDoc_EDIDC_DOCNUM");

    //   IdocNumber = IdocNumber.replaceFirst("^0*", "")
       
       message.setProperty("Idoc_Number",IdocNumber )	 
       map = message.getProperties();
       def P_LOREALGLN = map.get("P_LOREALGLN");

	   def date = new Date()
	   SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-hhmmssSSS");
	   String currentDate= formatter.format(date);
		
	   String _fileName = "5065000858001_" + P_LOREALGLN + "_ORDRSP_D96A_" + currentDate  +".txt"
        // String _fileName = IdocNumber+".edi"
	  
	  message.setHeader("CamelFileName",_fileName )	


	  return message;
}







