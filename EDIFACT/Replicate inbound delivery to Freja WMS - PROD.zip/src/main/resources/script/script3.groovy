import com.sap.gateway.ip.core.customdev.util.Message;
import java.io.StringWriter;
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def body = message.getBody(String.class)
    def properties = message.getProperties()

    def xmlIDoc = new XmlParser().parseText(properties.get("IDoc"))
    def xmlOutput = new XmlParser().parseText(body)

    // Navigate to the PurchaseOrder node. Assume there's only one PurchaseOrder for simplicity.
    def purchaseOrderNode = xmlOutput.PurchaseOrder

    // Loop through IDoc segments and update xmlOutput as needed.
    xmlIDoc.'**'.findAll { it.name() == 'E1ADRM1' && it.PARTNER_Q.text() == 'MF' }.each { adr ->
        def supplierNode = purchaseOrderNode.Supplier[0] // Assuming one Supplier node per PurchaseOrder for simplicity.
        
        // Update supplier details
        supplierNode.Id[0].value = adr.PARTNER_ID.text()
        supplierNode.Name[0].value = adr.NAME1.text()
        supplierNode.Address1[0].value = adr.STREET1.text()
        supplierNode.Address2[0].value = adr.STREET2.text() ?: ''
        supplierNode.Address3[0].value = adr.STREET3.text() ?: ''
        supplierNode.ZipCode[0].value = adr.POSTL_COD1.text() ?: ''
        supplierNode.City[0].value = adr.CITY1.text() 
        supplierNode.CountryCode[0].value = adr.COUNTRY1.text()
    }

    xmlIDoc.'**'.findAll { it.name() == 'E1EDT13' && it.QUALF.text() == '007' }.each { dt ->
        purchaseOrderNode.DeliveryDate[0].value = dt.NTANF.text()
    }

    // Serialize the modified xmlOutput back into a string.
    StringWriter writer = new StringWriter()
    new XmlNodePrinter(new PrintWriter(writer)).print(xmlOutput)
    String updatedXml = XmlUtil.serialize(xmlOutput)

    // Set the modified XML as the message body.
    message.setBody(updatedXml)
    return message;
}
