import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message processData(Message message) {
    // Define the company name - replace 'yourcompanyname' with actual company name or fetch from message/environment
    String companyName = "Croda"; // Example: "yourcompanyname"
    
    // Get current date and time
    Date now = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    String formattedDateTime = dateFormat.format(now);
    
    String fileID = message.getHeader('fileID', String).toString();
    
    // Construct the filename string
    String filename = "PurchaseOrder_standard_${companyName}_${formattedDateTime}_${fileID}.xml";
    
    // Store the filename in the message properties
    message.setProperty("filename", filename);
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.addAttachmentAsString("${filename}", message.getBody(String), "application/xml");
    }
    
    return message;
}
