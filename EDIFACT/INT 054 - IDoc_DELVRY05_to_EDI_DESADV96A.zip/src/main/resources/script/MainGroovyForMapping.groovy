import com.sap.it.api.mapping.*;

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String itemDescription(String description,String fieldIdentifier, MappingContext context){
    String outputDescription = "";
    if(fieldIdentifier.equals("1")){
        def fieldLength = description.length();
        if(fieldLength > 0 && fieldLength <= 35){
            outputDescription = description.substring(0,fieldLength);
        }else if(fieldLength > 35){
            outputDescription = description.substring(0,35);
        }else{
            outputDescription = "";
        }
    }else{
        def fieldLength = description.length();
        if(fieldLength > 35 && fieldLength <= 70){
            outputDescription = description.substring(35,fieldLength);
        }else if(fieldLength > 70){
            outputDescription = description.substring(35,70);
        }else{
            outputDescription = "";
        } 
    }
	return outputDescription 
}

def void e1edk03Datum002(String[] iddat,String[] datum, Output output, MappingContext context) {
        String dateValue = "";

        for(int i = 0; i < iddat.length; i++){
            if(iddat[i].equals("002")){
                dateValue = datum[i];
                break;
            }
        }
        output.addValue(dateValue);
}


def String e1edt13qualf006(String QUALF,String ISDD, String NTANF,MappingContext context){
    String outputValue = "";
    if(QUALF.equals("006")){
        if(!ISDD.equals("0")){
            outputValue = ISDD;
        }else{
            outputValue = NTANF;
        }
    }
    
	return outputValue 
}

def String Split_String(String inputString,String separatorChar, String outputPosition, MappingContext context){
    String outputValue = "";
    if(inputString.length() > 0){
        if(inputString.contains(separatorChar)){
            if(outputPosition == "0"){
                outputValue = inputString.substring(0,inputString.indexOf(separatorChar));
            }else{
                outputValue = inputString.substring(inputString.indexOf(separatorChar)+1);
            }
            
        }else{
            if(outputPosition == "0"){
                outputValue = inputString;
            }else{
                outputValue = "";
            }  
        }
    }else{
        outputValue = "";
    }
	return outputValue 
}


