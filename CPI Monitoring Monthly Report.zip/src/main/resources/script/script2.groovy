import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

def Message processData(Message message) {
  
  //Properties 
       map = message.getProperties();
       manualstartdate = map.get("manualstartdate");
       manualenddate = map.get("manualenddate");
        // Get previous Date
    def yesterday = new Date().previous();
   // def yesterday = new Date();
    def date = yesterday.format('MM/dd/yyyy');
    String d=yesterday.format('dd');
    String m=yesterday.format('MM');
    int M = Integer.parseInt(m);
    M = M - 1;
    String y=yesterday.format('yyyy');
    String month = new java.text.DateFormatSymbols().months[ M ];
 
     message.setProperty("date", d);
     message.setProperty("year", y);
     message.setProperty("month", month);
  
     //Start Date 
    if(manualstartdate == ''){// if Manula Start date is empty
       
    Date inputDate_parsed=new SimpleDateFormat("MM/dd/yyyy").parse(date);  

    DateFormat dateFormat_required = new SimpleDateFormat("yyyy-MM-01'T'00:00:00.000");

    def converted_datetime=dateFormat_required.format(inputDate_parsed);
    
      message.setProperty("startdate", converted_datetime);
    }
    else{
      
       Date inputDate_parsed2=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").parse(manualstartdate);  

       DateFormat dateFormat_required2 = new SimpleDateFormat("MM/dd/yyyy");

       def converted_datetime2=dateFormat_required2.format(inputDate_parsed2);
       
       def manual_startdate = new Date(converted_datetime2);
       
    //Manula Start date
    String ms_d=manual_startdate.format('dd');
    String ms_m=manual_startdate.format('MM');
    int ms_M = Integer.parseInt(ms_m);
    ms_M = ms_M - 1;
    String ms_y=manual_startdate.format('yyyy');
    String ms_month = new java.text.DateFormatSymbols().months[ ms_M ];
     message.setProperty("sdate", ms_d);
     message.setProperty("syear", ms_y);
     message.setProperty("smonth", ms_month);
     
     message.setProperty("startdate", manualstartdate);
    
    }
    
    if(manualenddate == ''){ // if Manula End date is empty
    ///end date
    Date inputDate_parsed1=new SimpleDateFormat("MM/dd/yyyy").parse(date);  

    DateFormat dateFormat_required1 = new SimpleDateFormat("yyyy-MM-dd'T'23:59:59.000");

    def converted_datetime1=dateFormat_required1.format(inputDate_parsed1);
    
    message.setProperty("enddate", converted_datetime1);
    }
    else{
        
    Date inputDate_parsed3=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").parse(manualenddate);  

    DateFormat dateFormat_required3 = new SimpleDateFormat("MM/dd/yyyy");

    def converted_datetime3=dateFormat_required3.format(inputDate_parsed3);
    
    def manual_enddate = new Date(converted_datetime3);
    
        //Manula End date
    String me_d=manual_enddate.format('dd');
    String me_m=manual_enddate.format('MM');
    int me_M = Integer.parseInt(m);
    me_M = me_M - 1;
    String me_y=manual_enddate.format('yyyy');
    String me_month = new java.text.DateFormatSymbols().months[ me_M ];
     message.setProperty("edate", me_d);
     message.setProperty("eyear", me_y);
     message.setProperty("emonth", me_month);
     
     message.setProperty("enddate", manualenddate);
    }
    return message;
       return message;
}