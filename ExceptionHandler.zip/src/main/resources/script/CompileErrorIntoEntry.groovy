import groovy.xml.MarkupBuilder
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve properties from the message
    def messageGuid = message.getProperty("MessageGuid")
    def alternateWebLink = message.getProperty("AlternateWebLink")
    def integrationFlowName = message.getProperty("IntegrationFlowName")
    def status = message.getProperty("Status")
    def logStart = message.getProperty("LogStart")
    def logEnd = message.getProperty("LogEnd")
    def error = message.getBody(String).replaceAll("\\n", "")
    def packageName = message.getProperty("PackageName")
    def packageId = message.getProperty("PackageId")
    def type = message.getProperty("Type")
    def name = message.getProperty("Name")
    def id = message.getProperty("Id")

    // Add more properties as needed

    // Use MarkupBuilder to create the XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)

    xml.Entry {
        MessageGuid(messageGuid)
        AlternateWebLink(alternateWebLink)
        IntegrationFlowName(integrationFlowName)
        Status(status)
        LogStart(logStart)
        LogEnd(logEnd)
        'Error'(error)
        PackageName(packageName)
        PackageId(packageId)
        Type(type)
        Name(name)
        Id(id)
    }

    // Set the XML string as the message body
    message.setBody(writer.toString())

    return message
}
