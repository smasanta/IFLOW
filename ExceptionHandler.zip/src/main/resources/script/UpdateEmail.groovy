import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
    // Get the JSON string from the message body
    def body = message.getBody(String.class);
    
    // Parse the JSON string
    def jsonSlurper = new JsonSlurper();
    def object = jsonSlurper.parseText(body);
    
    // Retrieve the flow package name from message properties
    def flowPackageName = message.getProperty("IntegrationArtifact_PackageName");
    
    // Initialize the email list to be set in the property
    def emails = [];
    
    // Loop through each package in the JSON
    object.Configurations.Package.each { pkg ->
        if (pkg.Name == flowPackageName) {
            emails = pkg.Emails.Email.join(",");
            message.setProperty("Email", emails);
            message.setBody(""); // If you want to empty the body
            return message; // Exit the loop and script execution
        }
    }
    
    if (emails.isEmpty()) {
        // Set default or handle the case when no matching package name is found
    }
    
    // Set the updated body if needed
    // message.setBody(newBody);
    
    return message;
}

