import com.sap.gateway.ip.core.customdev.util.Message;
import java.text.SimpleDateFormat;
import groovy.xml.StreamingMarkupBuilder;

def nodeToXml(node) {
    def builder = new StreamingMarkupBuilder()
    def xmlStr = builder.bind {
        mkp.yield node
    }
    return xmlStr.toString()
}

def Message processData(Message message) {
    def body = message.getBody(String);
    def map = message.getProperties();
    
    if (body) {
        try {
            def xml = new XmlSlurper().parseText(body)
            def counter = new StringBuilder();
            
            xml.entry.each { entry ->
                def today = (new Date()-1).format( 'yyyy-MM-dd' )
                def LogEnd = entry.content.properties.LogEnd.toString()

                def format = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss")
                def LogEndDateTime = format.parse(LogEnd.substring(0,19))
                
                def currentDateTime = new Date()
                def formattedDateTime = format.format(currentDateTime)
                // Subtract 315 seconds (in milliseconds)
                currentDateTime = new Date(currentDateTime.getTime() - 315 * 1000)
                
                if(currentDateTime.compareTo(LogEndDateTime) < 0){
                    // Convert the entry object back to XML string
                    def xmlString = nodeToXml(entry)
                    // Remove the unwanted prefixes
                    xmlString = xmlString.replaceAll("<tag0:", "<")
                    xmlString = xmlString.replaceAll("<m:", "<")
                    xmlString = xmlString.replaceAll("<d:", "<")
                    
                    xmlString = xmlString.replaceAll("</tag0:", "</")
                    xmlString = xmlString.replaceAll("</m:", "</")
                    xmlString = xmlString.replaceAll("</d:", "</")
                    
                    counter.append(xmlString)
                    counter.append('\n')
                }
            }
            message.setBody(counter.toString());
        } catch (Exception e) {
            message.setBody("Error parsing XML: ${e.message}");
        }
    } else {
        message.setBody("No XML content found in the message body.");
    }
    
    return message;
}
